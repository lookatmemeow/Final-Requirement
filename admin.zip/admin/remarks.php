<p class="p-4">Order status: </p>

<div class="text-center">
    <button class="btn btn-primary" id="confirm" type="button" onclick="Remarks()">Delivered</button>
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
</div>

<style>
    #uni_modal .modal-footer {
        display: none
    }
</style>
<script>
    function Remarks() {
        start_load()
        $.ajax({
            url: 'ajax.php?action=remarks',
            method: 'POST',
            data: {
                id: '<?php echo $_GET['id'] ?>'
            },
            success: function(resp) {
                if (resp == 1) {
                    alert_toast("Done")
                    setTimeout(function() {
                        location.reload()
                    }, 1500)
                }
            }
        })
    }
</script>