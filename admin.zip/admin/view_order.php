<div class="container-fluid">
<?php
?>
					
	
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Qty</th>
				<th>Price</th>
				<th>Orders</th>
				<th>Amount</th>
				<!-- <th>Contact</th> -->

			</tr>
		</thead>
		<tbody>
			<?php 
			$total = 0;
			include 'db_connect.php';
			$qry = $conn->query("SELECT * FROM order_list o inner join product_list p on o.product_id = p.id  where order_id =".$_GET['id']);
			while($row=$qry->fetch_assoc()):
				$total += $row['qty'] * $row['price'];
			?>
			<tr>
				<td>x<?php echo $row['qty'] ?></td>
				<td>P <?php echo number_format($row['price'], 2,'.', ',')?></td>
				<td><?php echo $row['name'] ?></td>
				<td><?php echo number_format($row['qty'] * $row['price'],2) ?></td>
				<!-- <td>COD</td> -->
				<!-- <td><?php echo $row['mobile']?></td> -->
			</tr>
		<?php endwhile; ?>
		</tbody>
		<tfoot>
			<tr>
				<th colspan="3" class="text-right">TOTAL</th>
				<th >P <?php echo number_format($total,2) ?></th>
			</tr>

		</tfoot>
	</table>
	
	<div class="text-center">
		<?php 
		$i = 1;
    
    include 'db_connect.php';
    $qry = $conn->query("SELECT a.*, sum(c.price * b.qty) as totals FROM orders a
        join order_list b On b.order_id = a.id
        JOIN product_list c ON c.id = b.product_id
        GROUP by a.id
        order by FIELD(a.status, 1,0), a.dateordered asc");
    while ($row = $qry->fetch_assoc()) :
    ?>
	 
        <!-- <form method="post" action="sms_sent.php"> -->
        <!-- <label for="number">Number</label> -->
        <!-- <input type="text" name="number" id="number" value="<?php echo $row['mobile']?>"/> -->
        <!-- <label for="message">Message</label> -->
        <!-- <textarea name="message" id="message"></textarea> -->
        <!-- <fieldset> -->
            <!-- <legend>Provider</legend> -->
            <label >
                <!-- <input type="radio" name="provider" value="infobip" checked /> Infobip -->
            </label>
            <!-- <br /> -->
            <!-- <label>
                <input type="radio" name="provider" value="twilio" /> Twilio
            </label> -->
        </fieldset>
        <!-- <button onclick="confirm_order()" href="page=orders">Confirm & Send SMS</button> -->
		
		<br>
		
    </form>
   <!-- <h5> Contact #: <?php echo $row['mobile']?></h5> -->
    <?php endwhile; ?>
	<button class="btn btn-primary" id="sms2" type="button" onclick="confirm_order()" >Confirm</button>
	
	
		<!-- <button class="btn btn-primary" id="confirm" type="button" onclick="confirm_order()">Confirm</button> -->
		<!-- <form method="post" action="sms_sent.php" style="visibility: hidden">
			<label for="number">Number</label>
			<input type="text" name="number" id="number" />
			<label for="message">Message</label>
			<textarea name="message" id="message"></textarea>
			<fieldset style="visibility: hidden"> -->
				<!-- <legend>Provider</legend> -->
				<!-- <label > -->
					<!-- <input type="radio" name="provider" value="infobip" checked /> Infobip -->
				<!-- </label> -->
				<!-- <br /> -->
				<!-- <label>
					<input type="radio" name="provider" value="twilio" /> Twilio
				</label> -->
			<!-- </fieldset> -->
			<!-- <button class="btn btn-primary" type="button">Send</button> -->
		<!-- </form> -->
		<!-- <button class="btn btn-primary" type="button" onclick="confirm_order()">Confirm & Send SMS</button> -->
        <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->

	</div>
</div>
<style>
	#uni_modal .modal-footer{
		display: none
	}
</style>

<script>
	function confirm_order(){
		start_load()
		$.ajax({
			url:'ajax.php?action=confirm_order',
			method:'POST',
			data:{id:'<?php echo $_GET['id'] ?>'},
			success:function(resp){
				if(resp == 1){
					// alert_toast("Order confirmed. SMS was sent")
					alert_toast("Order confirmed.")
                        setTimeout(function(){
                            location.reload()
                        },1500)
				}
			}
		})
		
	}
</script>