<div class="container-fluid">
<div style="margin-left: 0%; margin-top: 3%;">

		<p>
			<a href="./index.php?page=orders" class="btn btn-info btn-lg">
				<span class="glyphicon glyphicon-refresh"></span> Refresh
			</a>
		</p>
	</div>

	<div class="card">
		<div class="card-body ">
			<table class="table table-bordered table-responsive" id="order_table">
				<thead>
					<tr>
						<!-- <th>#</th> -->
						<th>Order #</th>
						<th>Date</th>
						<th>Name</th>
						<th>Address</th>
						<th>Email</th>
						<th>Mobile</th>
						<th>Total</th>
						<th>Type</th>
						<th>Ref Image (if Gcash)</th>
						<th>Action</th>
						<th>Status</th>
						<!-- <th>Remarks</th> -->
					</tr>
				</thead>
				<tbody>

					<?php
					$i = 1;
					include 'db_connect.php';
					$qry = $conn->query("SELECT a.*, sum(c.price * b.qty) as totals FROM orders a
						join order_list b On b.order_id = a.id
						JOIN product_list c ON c.id = b.product_id
						GROUP by a.id
						order by FIELD(a.status, 1,0), a.dateordered asc");
					while ($row = $qry->fetch_assoc()) :
					?>
						<tr>
							<!-- <td><?php echo $i++ ?></td> -->
							<td><?php echo $row['id'] ?></td>
							<td><?php echo date_format(date_create($row['dateordered']), 'F d, Y h:i A') ?></td>
							<td><?php echo $row['name'] ?></td>
							<td><?php echo $row['address'] ?></td>
							<td><?php echo $row['email'] ?></td>
							<td><?php echo $row['mobile'] ?></td>
							<td><?php echo number_format($row['totals'], 2, '.', ',') ?></td>
							<td><?php echo $row['type'] ?></td>
							<td>
								<?php if ($row['file'] != '') : ?>	
									<!-- <a href="assets/gcashref/<?php echo $row['file'] ?>" target="_blank" ><i class="fa fa-file"></i></span></a> -->
									<a class="fa fa-file" href="" target="" data-toggle="modal" data-target="#exampleModal_gcash_<?php echo $row['id'] ?>"></i></span></a>
									<div class="modal fade" id="exampleModal_gcash_<?php echo $row['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel_<?php echo $row['id'] ?>" aria-hidden="true">
									
										<div class="modal-dialog" role="document">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title" id="exampleModalLabel">REFERENCE #</h5>
													<button type="button" class="close" data-dismiss="modal" aria-label="Close">
														<span aria-hidden="true">&times;</span>
													</button>
												</div>
												
												<div class="modal-body text-center">
												<!-- RESERVATION -->
												<?php
												?>
												<img src="assets/gcashref/<?php echo $row['file'] ?>" width="70%" height="80%" style="margin-bottom: 5%;">
												
												<h4>Reference #: <?php echo wordwrap($row['ref'],4, '-',true)?></p>

												<!-- <h4>Reference #: <?php echo wordwrap($row['ref'],4, '-',true )?></p> -->
												</div>
												<div class="modal-footer">
													<!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
													<button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
												</div>
											</div>
										</div>
									</div>
								<?php endif; ?>
								
							</td>
							<td>
								<button class="btn btn-sm btn-primary view_order mt-1" data-id="<?php echo $row['id'] ?>">View Order</button>
								<!-- <button class="btn btn-sm btn-primary sms mt-1" data-id="<?php echo $row['id'] ?>">View Order</button> -->
								<button class="btn btn-sm btn-primary void_order mt-1" style="background-color: red;border-color:red;" data-id="<?php echo $row['id'] ?>">Void Order</button>
							</td>
							<?php if ($row['status'] == 1) : ?>
								<td class="text-center"><span class="badge badge-success">Confirmed</span></td>
								<!-- <span class="badge badge-success">An SMS was sent to <?php echo $row['name']?> with SMS #: <?php echo $row['mobile']?></span> -->
								

							<?php else : ?>
								<td class="text-center"><span class="badge badge-secondary">For Confirmation</span></td>
							<?php endif; ?>

							

							


						</tr>
					<?php endwhile; ?>
				</tbody>
			</table>
		</div>
	</div>


</div>
<script>
	$('.view_order').click(function() {
		uni_modal('Order details', 'view_order.php?id=' + $(this).attr('data-id'))
	})

	$('.void_order').click(function() {
		uni_modal('Confirm Void Order', 'confirmation_void.php?id=' + $(this).attr('data-id'))
	})

	$('.Remarks').click(function() {
		uni_modal('Add a remark', 'remarks.php?id=' + $(this).attr('data-id'))
	})
	// let table = new DataTable('#order_table');
	$('#order_table').DataTable({
		"aaSorting": []
	})
	
	$('.sms').click(function() {
		uni_modal('Send Confirmation SMS', 'sms.php?id=' + $(this).attr('data-id'))
	});
</script>