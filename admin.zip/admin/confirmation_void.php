<p class="p-4">Are you sure you want to void this order?</p>
</table>
<div class="text-center">
    <button class="btn btn-primary" id="confirm" type="button" onclick="void_order()">Void Order</button>
    <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
</div>
<style>
    #uni_modal .modal-footer {
        display: none
    }
</style>
<script>
    function void_order() {
        start_load()
        $.ajax({
            url: 'ajax.php?action=void_order',
            method: 'POST',
            data: {
                id: '<?php echo $_GET['id'] ?>'
            },
            success: function(resp) {
                if (resp == 1) {
                    alert_toast("Void confirmed.")
                    setTimeout(function() {
                        location.reload()
                    }, 1500)
                }
            }
        })
    }
</script>