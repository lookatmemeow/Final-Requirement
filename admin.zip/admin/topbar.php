<style>
	.logo {
    /* margin: auto; */
    /* font-size: 20px; */
    /* background:red; */
    /* padding: 5px 11px; */
    /* border-radius: 50% 50%; */
    /* color: #000000b3; */
    /* width: 100%; */
    /* height: 100%; */
    /* position: flex; */
}
#logout_admin:hover{
  opacity: 50%;
  border-color: red;
}
</style>


<nav class="navbar navbar-light bg-light fixed-top " style="">
  <div class="container-fluid mt-2">
  	<div class="col-lg-12" style="margin-bottom:20px;">
  		<div class="col-md-1 float-left" style="display: flex;">
            <!-- <div class="logo">
                <h2 class="text-center"><img src="" width="60%"></h2>
  			        </div> -->
  		</div>
      <div class="col-md-4 my-2">
        <large style=""><b><?php echo $_SESSION['setting_name']; ?> - Admin Panel</b></large>
      </div>
      <!-- <div class="col-md-6 float-left">
        <large style="font-family: 'Dancing Script', cursive !important;"><b><?php echo $_SESSION['setting_name']; ?> - Admin Panel</b></large>
      </div> -->
	  	  <div class="col-md-2" >
	  		<!-- <a class="text-dark"><?php echo $_SESSION['login_name'] ?> </a> -->
	  		<!-- <a class="text-dark">Logout</a> -->
            <!-- <a onclick=confirmlogout() id="logout_admin" href="ajax.php?action=logout" class="text-dark" style=""><span>    </span> <i class="fa fa-power-off" style="color:red;"></i></a> -->
        </div>
        </div>
  </div>
</nav>
  

<!-- 
<nav class="navbar navbar-light bg-light fixed-top " style="padding:0;height:3.5em">
  <div class="container-fluid mt-2 mb-2">
  	<div class="col-lg-12" style="margin-top: 1%;">
  		<div class="col-md-1 float-left" style="display: flex;">
        <div class="logo">
          <h2 class="text-center"><img src="" width="60%"></h2>
  			</div>
  		</div>
      <div class="col-md-4 float-left" >
        <large style=""><b><?php echo $_SESSION['setting_name']; ?> - Admin Panel</b></large>
      </div> -->
      <!-- <div class="col-md-4 float-left">
        <large style="font-family: 'Dancing Script', cursive !important;"><b><?php echo $_SESSION['setting_name']; ?> - Admin Panel</b></large>
      </div> -->
	  	<!-- <div class="col-md-2 float-right">
	  		<a class="text-dark"><?php echo $_SESSION['login_name'] ?> </a>
        <a onclick=confirmlogout() id="logout_admin" href="ajax.php?action=logout" class="text-dark" style="font-size: 20px;margin-left: 10px;;"> <i class="fa fa-power-off"></i></a>
	    </div>
    </div>
  </div>
  
</nav> -->

<script>
	function confirmlogout() {
		if (confirm("Are you sure you want to logout?")) {
			location.href = "admin/ajax.php?action=logout2";
		}
	}
</script>