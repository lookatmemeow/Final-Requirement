<div class="container-fluid">
	<div style="margin-left: 0%;">
		<p>
			<a href="./index.php?page=orders" class="btn btn-info btn-lg">
				<span class="glyphicon glyphicon-refresh"></span> Refresh
			</a>
		</p>
	</div>

	<div class="card">
		<div class="card-body">
			<table class="table table-bordered" id="order_table">
				<thead>
					<tr>
						<!-- <th>#</th> -->
						<th>Reservation #</th>
						<th>Date</th>
						<th>Name</th>
						<th>Address</th>
						<th>Email</th>
						<th>Mobile</th>
						<th>Total</th>
						<th>Type</th>
						<th>Ref Image</th>
						<!-- <th>Status</th> -->
						<!-- <th>Action</th> -->
						<th>Remarks</th>
					</tr>
				</thead>
				<tbody>

					<?php
					$i = 1;
					include 'db_connect.php';
					$qry = $conn->query("SELECT a.*, sum(c.price * b.qty) as totals FROM orders a
						join order_list b On b.order_id = a.id
						JOIN product_list c ON c.id = b.product_id
						GROUP by a.id
						order by FIELD(a.status, 1,0), a.dateordered asc");
					while ($row = $qry->fetch_assoc()) :
					?>
						<tr>
							<!-- <td><?php echo $i++ ?></td> -->
							<td>RN#<?php echo $row['id'] ?></td>
							<td><?php echo date_format(date_create($row['dateordered']), 'F d, Y h:i A') ?></td>
							<td><?php echo $row['name'] ?></td>
							<td><?php echo $row['address'] ?></td>
							<td><?php echo $row['email'] ?></td>
							<td><?php echo $row['mobile'] ?></td>
							<td><?php echo number_format($row['totals'], 2, '.', ',') ?></td>
							<td><?php echo $row['type'] ?></td>
							<td>
								<?php if ($row['file'] != '') : ?>
									<a href="assets/gcashref/<?php echo $row['file'] ?>" target="_blank"><i class="fa fa-file"></i></span></a>
								<?php endif; ?>
							</td>
							<?php if ($row['status'] == 1) : ?>
								<!-- <td class="text-center"><span class="badge badge-success">Confirmed</span></td> -->
							<?php else : ?>
								<!-- <td class="text-center"><span class="badge badge-secondary">For Verification</span></td> -->
							<?php endif; ?>

							<!-- <td>
								<button class="btn btn-sm btn-primary view_order" data-id="<?php echo $row['id'] ?>">View Order</button>
								<button class="btn btn-sm btn-primary void_order" style="background-color: red;border-color:red;" data-id="<?php echo $row['id'] ?>">Void Order</button>
							</td> -->

							<!-- REMARKs -->
							<td>
								<?php if ($row['Remarks'] == 'Delivered') : ?>
									<span class="badge badge-success">Delivered</span>
								<?php else : ?>
									<button class="btn btn-sm btn-primary Remarks" data-id="<?php echo $row['id'] ?>">Add Remarks</button>
								<?php endif; ?>


							</td>




						</tr>
					<?php endwhile; ?>
				</tbody>
			</table>
		</div>
	</div>


</div>
<script>
	$('.view_order').click(function() {
		uni_modal('Order', 'view_order.php?id=' + $(this).attr('data-id'))
	})

	$('.void_order').click(function() {
		uni_modal('Order', 'confirmation_void.php?id=' + $(this).attr('data-id'))
	})

	$('.Remarks').click(function() {
		uni_modal('Order', 'remarks.php?id=' + $(this).attr('data-id'))
	})
	// let table = new DataTable('#order_table');
	$('#order_table').DataTable({
		"aaSorting": []
	});
</script>